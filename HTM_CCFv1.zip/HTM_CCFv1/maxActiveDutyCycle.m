%% NOTE******:%This program is strictly for research purposes and should be used 
%with care. The Authors will not provide any warranty for resulting
%damages from use of this software

%Author: E.N. Osegi
%Affiliation: National Open University of Nigeria(NOUN)
%Version: v1
%Initial Date: 09-02-2016
%Revision Date:10-01-2017 (October)
%Maximum Active Duty-Cycle

%% Function maxActiveDutyCycle:

function max_duty = maxActiveDutyCycle(activeDutyCycle)


    
    max_duty = max(activeDutyCycle);
    
end